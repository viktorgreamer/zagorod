<?php
return [
    'components' => [
        /*'db' => ['class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=141.8.195.92;dbname=a0086640_zagorod',
            'username' => 'a0086640_pr',
            'password' => 'WindU160',
            'charset' => 'utf8',
        ],*/

        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=zagorod',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
    ],
];
