<?php
/**
 * Created by PhpStorm.
 * User: Анастсия
 * Date: 15.09.2018
 * Time: 15:24
 */

namespace common\models;


class Icons
{
    const REMOVE = '<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>';
    const ADD = '<span class="glyphicon glyphicon-plus" aria-hidden="true"></span>';
    const MOVE_UP = '<span class="glyphicon glyphicon-menu-up" aria-hidden="true"></span>';
    const MOVE_DOWN = '<span class="glyphicon glyphicon-menu-down" aria-hidden="true"></span>';
    const EDIT = '<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>';
}